const fetch = require("node-fetch");

exports.handler = async function (event, context) {
  const { message } = JSON.parse(event.body);

  const resposta = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": "Bearer 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"
    },
    body: JSON.stringify({
      model: "gpt-3.5-turbo",
      messages: [{ role: "user", content: message }],
      temperature: 0.7
    })
  });

  const data = await resposta.json();
  const reply = data.choices?.[0]?.message?.content || "Desculpe, não consegui responder.";

  return {
    statusCode: 200,
    body: JSON.stringify({ reply })
  };
};
