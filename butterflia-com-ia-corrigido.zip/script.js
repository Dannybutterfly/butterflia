document.addEventListener("DOMContentLoaded", () => {
  const chat = document.getElementById("chat");
  const inputTexto = document.getElementById("input-texto");
  const btnEnviar = document.getElementById("btn-enviar");

  function adicionarMensagem(texto, classe) {
    const msg = document.createElement("div");
    msg.classList.add("mensagem", classe);
    msg.textContent = texto;
    chat.appendChild(msg);
    chat.scrollTop = chat.scrollHeight;
  }

  async function enviarParaIA(pergunta) {
    adicionarMensagem("Você: " + pergunta, "usuario");

    adicionarMensagem("Butterflia está digitando...", "bot");

    const resposta = await fetch("/.netlify/functions/chatgpt", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: pergunta })
    }).then(res => res.json());

    const msgs = document.querySelectorAll(".bot");
    msgs[msgs.length - 1].remove();

    adicionarMensagem("Butterflia: " + resposta.reply, "bot");
  }

  btnEnviar.addEventListener("click", () => {
    const texto = inputTexto.value.trim();
    if (texto) {
      enviarParaIA(texto);
      inputTexto.value = "";
    }
  });

  inputTexto.addEventListener("keypress", (e) => {
    if (e.key === "Enter") btnEnviar.click();
  });
});
